<div class="footer">
  <p>copyrights reserved</p>
</div>