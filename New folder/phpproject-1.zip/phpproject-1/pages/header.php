<div class="header">
  <a href="index.php"><img src="images/header.jpeg" width=100% height=300px></a>
</div>