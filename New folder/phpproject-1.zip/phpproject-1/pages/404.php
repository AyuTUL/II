
<div class="column">
<img src="images/404.jpg">
</div>