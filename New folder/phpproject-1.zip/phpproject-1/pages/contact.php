
<div class="column">
    <div class="contact">
      <div class="cotacttext">
    
      <h1>contact us at:</h1>
      <pre>
      Trinity Int'l College
      dillibazar height
      Kathmandu,Nepal
    </pre>
  </div>
  </div>
</div>