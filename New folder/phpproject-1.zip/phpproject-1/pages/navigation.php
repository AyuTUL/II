<nav>
  <a href="index.php?id=home">Home</a>
  <a href="index.php?id=gallery">Gallery</a>
  <a href="index.php?id=about">About</a>
  <a href="index.php?id=contact">Contact me</a>

  <a href="index.php?id=register">Register</a>
  <a href="index.php?id=view">view records</a>
  <a href="index.php?id=help">know the steps</a>
  <a href="index.php?id=notebook">PHP notebook</a>



</nav>