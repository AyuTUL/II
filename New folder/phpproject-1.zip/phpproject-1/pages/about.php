
<div class="column">
    

  <p>What Can PHP Do?
    <ol ty>
    <li>PHP can generate dynamic page content</li>
    <li>PHP can create, open, read, write, delete, and close files on the server</li>
    <li>PHP can collect form data</li>
    <li>PHP can send and receive cookies</li>
    <li>PHP can add, delete, modify data in your database</li>
    <li>PHP can be used to control user-access</li>
    <li>PHP can encrypt data</li>
  </ol>
</p>
  </div>