<?php
include 'database/database.php';//include database file from the folder
  $sqlexe="select * from scrud";
  $r=mysqli_query($connection,$sqlexe);//performs query against database and stores in $r
?>
<div class="column">
  <h2 align="center"> Details informations are:</h2>
  
<table id="students" align="center"><!--table creation with row and column-->
  
    <tr>
      <th>sid</th>
      <th>sname</th>
      <th>semail</th>
      <th>spassword</th>
      <th colspan="2">actions</th>
    </tr>
    <?php
    $sd=1;
    while ($res = mysqli_fetch_array($r))
      //mysqli_fetch_array() function fetches a result row as an associative array, a numeric array, or both.Note: Fieldnames returned from this function are case-sensitive.
    {
    ?>
    <tr>
          <td><?php echo $sd;?></td><!--prints sid-->
          <td><?php echo $res['sname'];?></td><!--prints sname from database-->
          <td><?php echo $res['semail'];?></td><!--prints email from database-->
          <td><?php echo $res['spassword'];?></td>
          <td><a href="update.php?sid=<?php echo $res['sid'];?>"><button>edit</button></a></td>
          <td><a href="delete.php?sid=<?php echo $res['sid'];?>"><button>delete</button></a></td>
    </tr>
  <?php
    $sd=$sd+1;
  }
  ?>
</table>
</div>