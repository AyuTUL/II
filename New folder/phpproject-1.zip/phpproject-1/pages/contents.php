
<div class="column">
    <img src="images/php.jpg" height=200px height=200px style="float:right;max-height: 100%;object-fit: cover;">

  <p>The purpose of the website refers to the brand's mission. Briefly explain how the company serves its customers and what visitors can expect from browsing the website. It may be helpful to state the purpose in concise, straightforward language, making it easy for your target audience to understand. You can also use white space to separate blocks of text and make the words easier to read online. The body of your welcome message can include details such as:

Products and services the business offers
Communities the company serves
Features that distinguish the brand from competitors
A call to action is a request for consumers to seek more information about your brand, and it embodies the purpose of the website. At the bottom of the welcome message, write a specific action for visitors to take. Consider the information your customers need to support your business. You can activate the text with a link that directs the user to another page of the website, such as the stock list or the directions to create an account. Other examples of a call to action include:

Signing up for a mailing list
Following the brand on social media
Purchasing tickets to an upcoming even
</p>
  </div>