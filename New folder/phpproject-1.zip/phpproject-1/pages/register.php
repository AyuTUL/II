<?php
include 'database/database.php';//include 
if(isset($_POST['Register']))
{
  $sname=$_POST['sname'];
  $semail=$_POST['semail'];
  $spassword=$_POST['spassword'];
  $spassword=md5($spassword);
  $sqlexe="insert into scrud(sname,semail,spassword) values('$sname','$semail','$spassword')";
  if(mysqli_query($connection,$sqlexe))//performs query against database
  {
    $message="new record added!!!";
  }
  else
  {
    echo"failed".mysqli_error($connection);
  }
}
//mysqli_close($connection);
?>
<div class="column">
  <div class="formwrapper">
<form action="" method="post">
 <div class="text">
  <h3>
    Register your detail:
   </h3>
   </div>
  <div class="formwidth">
      <label>Name</label>
          <input type="text" name="sname" required>
  </div>
  <div class="formwidth">
      <label>email</label>
         <input type="email" name="semail" required>
      </div>
  <div class="formwidth">
  <label>password</label>
        <input type="password" name="spassword" required>
  </div>
  <div class="bottompane">
      <input type="submit" class="buttom" value="Register" name="Register">
 </div>
</form>
  <span><?php if (isset($message)) { echo $message; } ?></span>

</div>
</div>