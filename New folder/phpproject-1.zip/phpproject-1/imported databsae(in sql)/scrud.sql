-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 15, 2023 at 11:16 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `scrud`
--

-- --------------------------------------------------------

--
-- Table structure for table `scrud`
--

CREATE TABLE `scrud` (
  `sid` int(11) NOT NULL,
  `sname` varchar(100) NOT NULL,
  `semail` varchar(100) NOT NULL,
  `spassword` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `scrud`
--

INSERT INTO `scrud` (`sid`, `sname`, `semail`, `spassword`) VALUES
(24, 'nurisa', 'nurisa@gmail.com', 'nurima'),
(25, 'sajinaaaa', 'sajindranath@gmail.com', '678900'),
(26, 'sajinadra nath ', 'sajindra nath@gmail.com', 'sajina'),
(27, 'erina shrestha', 'na@gmail.com', '0000023424242'),
(30, 'eion', 'uio@gmail.com', '675567'),
(33, 'Liban', 'Liban@gmail.com', 'Liban'),
(34, 'bibhuti', 'bibhuti@gmail.com', 'bibhuti'),
(35, 'sunananya', 'sunayan@gmail.com', '25f9e794323b453885f5181f1b624d0b');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `scrud`
--
ALTER TABLE `scrud`
  ADD PRIMARY KEY (`sid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `scrud`
--
ALTER TABLE `scrud`
  MODIFY `sid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
