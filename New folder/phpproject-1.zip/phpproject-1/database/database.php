<?php
$connection=mysqli_connect("localhost","root","","scrud");
if(!$connection)
{
  echo"database connection failed".mysqli_connect_error();
}
?>
