<!DOCTYPE html>
<html lang="en">
<head>
<title>CSS Template</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">


</head>
<body>
      <?php
        @$id=$_GET['id'];

      ?>

   <div class="header">
        <?php
          include 'pages/header.php';
        ?>
    </div>
    <div class="navigation">
      <?php
          include 'pages/navigation.php';
        ?>
    </div>
      <div class="contents"> 
      <?php
        
        switch ($id) 
        {
          case 'news':
            include 'pages/news.php';
            break;
          case 'about':
            include 'pages/about.php';
            break;
          case 'contact':
            include 'pages/contact.php';
            break;
          case 'Home':
            include 'index.php';
            break;
          case 'gallery':
            include 'pages/gallery.php';
            break;
          case 'view':
            include 'pages/view.php';
            break;
          
          case 'register':
            include 'pages/register.php';
            break;
          case 'edit':
            include'pages/update.php';
            break;
          case 'help':
            include 'pages/help.php';
            break;
          case 'notebook':
            include 'pages/notebook.php';
            break;
          default:
          include'pages/contents.php';
          
        }
        

        ?>
      </div>
      <div class="footer">
       
        <?php
          include 'pages/footer.php';
        ?>
      </div>


  
 



</body>
</html>


