<?php
include 'database/database.php';//include database file from the folder
    
if (isset($_POST['update'])) 
    {
        $id = $_GET['sid'];
        $sname = $_POST['sname'];
        $semail = $_POST['semail'];
        $spassword = $_POST['spassword'];
        $sql = "UPDATE scrud SET sname='$sname', semail='$semail',spassword='$spassword' WHERE sid='$id'"; 
        $result = mysqli_query($connection,$sql);//$conn->query($sql);// 
        if ($result == true) 
        {
            echo ("<script LANGUAGE='JavaScript'>
                 window.alert('Succesfully Updated');
                 window.location.href='index.php';
                 </script>");   
        }
        else
        {
            echo "Error:" . $sql . "<br>" . mysqli_error($connection);
        }
   } 
    $id = $_REQUEST['sid']; 
    $sql = "SELECT * FROM scrud WHERE sid='$id'";
    $result = mysqli_query($connection,$sql);
    $row=mysqli_fetch_array($result);
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>CSS Template</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="header">
        <?php
          include 'pages/header.php';
        ?>
    </div>
    <div class="navigation">
      <?php
          include 'pages/navigation.php';
        ?>
    </div>
<div class="column">
  <div class="formwrapper">
<form method="post">
 <div class="text">
  <h3>
    update  your detail:
   </h3>
   </div>
  <div class="formwidth">
      <label>Name</label>
          <input type="text" name="sname" value="<?php  echo $row['sname'];?>">
          <input type="hidden" name="id" value="<?php $row['sid']; ?>">

  </div>
  <div class="formwidth">
      <label>email</label>
         <input type="email" name="semail" name="semail" value="<?php echo $row['semail']; ?>">
      </div>
  <div class="formwidth">
  <label>password</label>
        <input type="password" name="spassword" value="<?php echo $row['spassword']; ?>">
  </div>
  <div class="bottompane">
    <input type="submit" name="update" value="click to update">
 </div>
</form>
</div>