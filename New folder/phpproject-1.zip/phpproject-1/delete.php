<?php
include 'database/database.php';//include database file from the folder
  
  //$r=//performs query against database and stores in $r

     $user_id = $_GET['sid'];

    $sql = "DELETE FROM `scrud` WHERE `sid`='$user_id'";

     $result = mysqli_query($connection,$sql);

     if ($result == TRUE) 
     {

        echo ("<script LANGUAGE='JavaScript'>
                 window.alert('Succesfully deleted');
                 window.location.href='index.php';
                 </script>");

    }
    else
    {

        echo "Error:" . $sql . "<br>" . mysqli_connect_error();

    }

//} 

?>